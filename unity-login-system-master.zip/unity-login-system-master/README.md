# unity-login-system

A framework for creating a login/registration system in unity relying on PHP and MySql.
